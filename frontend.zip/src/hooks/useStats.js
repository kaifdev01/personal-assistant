import { useState, useEffect, useCallback } from "react";
import { useApp } from "../context/AppContext";
import { WEEKLY_STATS } from "../data/mockData";

// Returns prayer completion count and percentage for today
export function usePrayerStats() {
  const { state } = useApp();
  const completed = Object.values(state.prayers).filter(Boolean).length;
  const total = 5;
  return { completed, total, percentage: Math.round((completed / total) * 100) };
}

// Returns task stats for today
export function useTaskStats() {
  const { state } = useApp();
  const today = state.today;
  const todayTasks = state.tasks.filter(t => t.dueDate === today);
  const completed = todayTasks.filter(t => t.completed).length;
  const total = todayTasks.length;
  const score = total > 0 ? Math.round((completed / total) * 100) : 0;
  return { completed, total, score, todayTasks };
}

// Returns water intake percentage
export function useWaterStats() {
  const { state } = useApp();
  return {
    glasses: state.waterGlasses,
    goal: state.waterGoal,
    percentage: Math.round((state.waterGlasses / state.waterGoal) * 100),
  };
}

// Countdown/up timer hook
export function useTimer(initialSeconds = 0, countDown = false) {
  const [seconds, setSeconds] = useState(initialSeconds);
  const [running, setRunning] = useState(false);

  useEffect(() => {
    if (!running) return;
    const interval = setInterval(() => {
      setSeconds(s => {
        if (countDown && s <= 0) { setRunning(false); return 0; }
        return countDown ? s - 1 : s + 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [running, countDown]);

  const start = useCallback(() => setRunning(true), []);
  const pause = useCallback(() => setRunning(false), []);
  const reset = useCallback((val = initialSeconds) => { setRunning(false); setSeconds(val); }, [initialSeconds]);

  const format = (s) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;

  return { seconds, running, start, pause, reset, format: format(seconds) };
}

// Weekly analytics derived from stored state + mock
export function useWeeklyStats() {
  const { state } = useApp();
  // Merge mock data with real data for the current week
  const stats = WEEKLY_STATS.map((day, i) => ({
    ...day,
    // Override last day with real data
    ...(i === 6 ? {
      prayers: Object.values(state.prayers).filter(Boolean).length,
      water: state.waterGlasses,
      workout: state.workoutDone ? 1 : 0,
      calories: state.caloriesBurned,
    } : {}),
  }));
  return stats;
}

// Habit log for today
export function useHabitToday() {
  const { state } = useApp();
  const todayLog = state.habitLog[state.today] || {};
  return todayLog;
}
